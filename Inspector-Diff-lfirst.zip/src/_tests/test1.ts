/* 
 * This is test file #1 used to verify the extension functionality.
 * A simple example containing a single console.log call.
 */
// changed test comment
console.log("Hello, world!")
console.log("Another log from test1")
    