/* 
 * This is test file #2 used to verify the extension functionality.
 * It works similarly to test1.ts but allows testing multiple files.
 */
console.log("Test 2 works correctly")
console.log("Another log from test2")

